# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.


  module Tipo_separacion
 PARED = 0
 PUERTA = 1
  end
 #Lista_Tipo_separacion = [Tipo_separacion::PARED, Tipo_separacion::PUERTA]
    
   
    
  
  
  
   

